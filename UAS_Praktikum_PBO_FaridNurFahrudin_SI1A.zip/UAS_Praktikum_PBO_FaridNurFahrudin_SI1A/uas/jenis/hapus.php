<?php
require_once __DIR__ . '/../class/Auth.php';
require_once __DIR__ . '/../class/Jenis.php';

$auth = new Auth();
$auth->checkAuth();

$jenisObj = new Jenis();
$id = $_GET['id'];

// Cek apakah jenis ini digunakan di tabel tb_barang
$koneksi = $jenisObj->getConnection();
$query_check = "SELECT COUNT(*) as total FROM tb_barang WHERE kode_jenis='$id'";
$result_check = $koneksi->query($query_check);
$row_check = $result_check->fetch_assoc();

if ($row_check['total'] > 0) {
    // Jenis masih digunakan oleh barang, tampilkan pesan error
    header("Location: index.php?pesan=hapus_gagal&alasan=masih_digunakan");
} else {
    // Jenis tidak digunakan, hapus data
    if ($jenisObj->hapus_data($id)) {
        header("Location: index.php?pesan=hapus_sukses");
    } else {
        header("Location: index.php?pesan=hapus_gagal&alasan=database_error");
    }
}
?>

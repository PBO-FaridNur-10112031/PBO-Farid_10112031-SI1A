<?php
include '../header.php';
require_once __DIR__ . '/../class/Jenis.php';
$jenisObj = new Jenis();
$data_jenis = $jenisObj->tampil_data();
?>

<div class="mb-20">
    <h2>Data Gudang (Jenis Barang)</h2>
    <a href="tambah.php" class="btn btn-primary" style="width: auto;">+ Tambah Data</a>
</div>

<!-- Notification Messages -->
<?php
if (isset($_GET['pesan'])) {
    if ($_GET['pesan'] == "tambah_sukses") {
        echo "<div style='background-color: #d4edda; color: #155724; padding: 12px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #c3e6cb;'>✓ Data berhasil ditambahkan</div>";
    } else if ($_GET['pesan'] == "edit_sukses") {
        echo "<div style='background-color: #d4edda; color: #155724; padding: 12px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #c3e6cb;'>✓ Data berhasil diperbarui</div>";
    } else if ($_GET['pesan'] == "hapus_sukses") {
        echo "<div style='background-color: #d4edda; color: #155724; padding: 12px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #c3e6cb;'>✓ Data berhasil dihapus</div>";
    } else if ($_GET['pesan'] == "hapus_gagal") {
        $alasan = isset($_GET['alasan']) ? $_GET['alasan'] : 'unknown';
        if ($alasan == "masih_digunakan") {
            echo "<div style='background-color: #f8d7da; color: #721c24; padding: 12px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #f5c6cb;'>✗ Gagal menghapus: Jenis barang masih digunakan oleh data barang. Silakan hapus barang terlebih dahulu sebelum menghapus jenis ini.</div>";
        } else {
            echo "<div style='background-color: #f8d7da; color: #721c24; padding: 12px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #f5c6cb;'>✗ Gagal menghapus data. Silakan coba lagi.</div>";
        }
    } else if ($_GET['pesan'] == "tambah_gagal") {
        echo "<div style='background-color: #f8d7da; color: #721c24; padding: 12px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #f5c6cb;'>✗ Gagal menambahkan data. Silakan coba lagi.</div>";
    } else if ($_GET['pesan'] == "edit_gagal") {
        echo "<div style='background-color: #f8d7da; color: #721c24; padding: 12px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #f5c6cb;'>✗ Gagal memperbarui data. Silakan coba lagi.</div>";
    }
}
?>

<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Kode Jenis</th>
            <th>Jenis Barang</th>
            <th>Satuan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach($data_jenis as $row) {
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['kode_jenis']; ?></td>
            <td><?php echo $row['jenis']; ?></td>
            <td><?php echo $row['satuan']; ?></td>
            <td class="action-links">
                <a href="edit.php?id=<?php echo $row['kode_jenis']; ?>" class="edit">Edit</a>
                <a href="hapus.php?id=<?php echo $row['kode_jenis']; ?>" class="hapus" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

<?php include '../footer.php'; ?>
